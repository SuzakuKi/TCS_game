#include<iostream>
#include<fstream>
#include<vector>
#include<cstdlib>
#include<ctime>
using namespace std;

class JMATRIX // Использование данного класса предполагает, что ранее была прописана команда srand(time(0))
{	
	public:
		string s2,s3;
		int d, l, r, S, count, num;
		JMATRIX ()
		{
			ifstream in2("JMATRIX_level_2.txt");
			in2>>s2;
			ifstream in3("JMATRIX_level_3.txt");
			in3>>s3;
			count=s2.size()/9;
		}
		~JMATRIX()
		{
			s2.clear();
			s3.clear();
		}
		string get_obuch_level()
		{
			return "322X";
		}
		bool get_obuch_sucsess(string q)
		{
			if(q.size()==4) 
			{
				int tmp = 3*2-2*(q[0]-'0');
				return tmp>0;
			}
			else if(q[0]=='1')
			{
				return true;
			}
			return false;
			
		}
		string get_level2()
		{
			string ans="";
			num=(rand()%count)*9;
			for(int i=0; i<4; i++)
			{
				ans=ans+char(((((s2[num+i]-34))&240)>>4)+'0')+char(((((s2[num+i]-34))&15))+'0');
			}
			ans=ans+char(((((s2[num+4]-34))&240)>>4)+'0');
			for(int i=0; i<9; i++) if(ans[i]==':') ans[i]='X';
			S=(((s2[num+4]-34))&15);
			l=((s2[num+5]-34+256)%256)-((s2[num+6]-34+256)%256);
			r=((s2[num+7]-34+256)%256)-((s2[num+8]-34+256)%256);
			cout<<S<<" "<<d<<" "<<l<<" "<<r<<endl;
			return ans;
		}
		string get_level3()
		{
			string ans="";
			num=(rand()%count)*9;
			for(int i=0; i<4; i++)
			{
				ans=ans+char(((((s3[num+i]-34))&240)>>4)+'0')+char(((((s3[num+i]-34))&15))+'0');
			}
			ans=ans+char(((((s3[num+4]-34))&240)>>4)+'0');
			for(int i=0; i<9; i++) if(ans[i]==':') ans[i]='X';
			S=(((s3[num+4]-34))&15);
			l=((s3[num+5]-34+256)%256)-((s3[num+6]-34+256)%256);
			r=((s3[num+7]-34+256)%256)-((s3[num+8]-34+256)%256);
			cout<<S<<" "<<d<<" "<<l<<" "<<r<<endl;
			return ans;
		}
		string get_level(int n)
		{
			if(n==2) return get_level2();
			return get_level3();
		}
		bool get_sucsess(string q)
		{
			if(q.size()==9)
			{
				int det=(q[0]-'0')*((q[4]-'0')*(q[8]-'0')-(q[5]-'0')*(q[7]-'0'))-(q[1]-'0')*((q[3]-'0')*(q[8]-'0')-(q[5]-'0')*(q[6]-'0'))+(q[2]-'0')*((q[3]-'0')*(q[7]-'0')-(q[4]-'0')*(q[6]-'0'));
				return det<=r && det>=l;
			}
			else
			{
				cout<<"debug: "<<q<<" "<<S<<endl;
				if(q[0]=='0' && S==0 or q[0]=='1' && S==1) return true;
				return false;
			}
		}
};	



int main()
{
	// В среднем значение определителя - 120. Разброс по идее не большой.
	srand(time(0));
	JMATRIX level;
	for(int i=0; i<10; i++)
	{
		string s=level.get_level(2+i%2);
		cout<<s[0]<<" "<<s[1]<<" "<<s[2]<<endl<<s[3]<<" "<<s[4]<<" "<<s[5]<<endl<<s[6]<<" "<<s[7]<<" "<<s[8]<<endl;
		cin>>s; 
		cout<<(level.get_sucsess(s)==1 ? "Molodec" : "ajajajaj")<<endl<<endl;
	}
	
	
}