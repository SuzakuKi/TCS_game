#include<iostream>
#include<fstream>
#include<cstdlib>
#include<ctime>
#define ll long long
using namespace std;

int A[3][3]; // Определитель
int C[3][3]; // Копия определителя
int B[3][3]; // Паттерн неизвестных
int D[3][3]; // Копия паттерна

ofstream out1("true.txt");
ofstream out2("false.txt");
ofstream out3("no_ans.txt");
ofstream log("log.txt");

void make_new_det()
{
	for(ll i=0; i<3; i++)
	for(ll j=0; j<3; j++)
	{
		A[i][j]=rand()%1024-512;//8192-4096;
		C[i][j]=A[i][j];
	}
}
void make_new_pattern()
{
	ll q=1; //+rand()%3;
	for(ll i=0; i<3; i++)
	for(ll j=0; j<3; j++)
	{
		B[i][j]=0;
		D[i][j]=0;
	}
	for(ll i=0; i<q; i++)
	{
		B[rand()%3][rand()%3]=1;
	}
	for(ll i=0; i<3; i++)
	for(ll j=0; j<3; j++)
	{
		D[i][j]=B[i][j];
		if(D[i][j]==1) C[i][j]=0;
	}
	
}

ll get_det()
{
	return A[0][0]*(A[1][1]*A[2][2]-A[1][2]*A[2][1])-A[0][1]*(A[1][0]*A[2][2]-A[1][2]*A[2][0])+A[0][2]*(A[1][0]*A[2][1]-A[1][1]*A[2][0]);
}
ll get_det_C()
{
	return C[0][0]*(C[1][1]*C[2][2]-C[1][2]*C[2][1])-C[0][1]*(C[1][0]*C[2][2]-C[1][2]*C[2][0])+C[0][2]*(C[1][0]*C[2][1]-C[1][1]*C[2][0]);
}
void print_num(ll n)
{
	ll f=0;
	if(n<0) cout<<"-";
	else cout<<" ";
	n=abs(n);
	if(n/10000>0) 		      {cout<<n/10000;     f=1;} else cout<<" ";
	if((n/1000)%10>0 or f==1) {cout<<(n/1000)%10; f=1;} else cout<<" ";
	if((n/100)%10>0  or f==1) {cout<<(n/100)%10;  f=1;} else cout<<" ";
	if((n/10)%10>0   or f==1) {cout<<(n/10)%10;   f=1;} else cout<<" ";
	cout<<n%10;
}
void print()
{
	for(ll i=0; i<3; i++)
	{
		for(ll j=0; j<3; j++) {
			print_num(A[i][j]);
			cout<<" ";
		}
		cout<<endl;
	}
	for(ll i=0; i<3; i++)
	{
		for(ll j=0; j<3; j++)
		{
			cout<<B[i][j];
		}	
		cout<<endl;
	}
	cout<<endl;
}

void print_num3(ll n)
{
	ll f=0;
	if(n<0) out3<<"-";
	else out3<<" ";
	n=abs(n);
	if(n/10000>0) 		      {out3<<n/10000;     f=1;} else out3<<" ";
	if((n/1000)%10>0 or f==1) {out3<<(n/1000)%10; f=1;} else out3<<" ";
	if((n/100)%10>0  or f==1) {out3<<(n/100)%10;  f=1;} else out3<<" ";
	if((n/10)%10>0   or f==1) {out3<<(n/10)%10;   f=1;} else out3<<" ";
	out3<<n%10;
}
void print3()
{
	log<<"No_ans"<<endl<<endl;
	for(ll i=0; i<3; i++)
	{
		for(ll j=0; j<3; j++) {
			print_num3(A[i][j]);
			out3<<" ";
		}
		out3<<endl;
	}
	for(ll i=0; i<3; i++)
	{
		for(ll j=0; j<3; j++)
		{
			out3<<B[i][j];
		}	
		out3<<endl;
	}
	out3<<endl;
}


void print_num2(ll n)
{
	ll f=0;
	if(n<0) out2<<"-";
	else out2<<" ";
	n=abs(n);
	if(n/10000>0) 		      {out2<<n/10000;     f=1;} else out2<<" ";
	if((n/1000)%10>0 or f==1) {out2<<(n/1000)%10; f=1;} else out2<<" ";
	if((n/100)%10>0  or f==1) {out2<<(n/100)%10;  f=1;} else out2<<" ";
	if((n/10)%10>0   or f==1) {out2<<(n/10)%10;   f=1;} else out2<<" ";
	out2<<n%10;
}
void print2()
{
	log<<"Proval"<<endl<<endl;
	for(ll i=0; i<3; i++)
	{
		for(ll j=0; j<3; j++) {
			print_num2(A[i][j]);
			out2<<" ";
		}
		out2<<endl;
	}
	for(ll i=0; i<3; i++)
	{
		for(ll j=0; j<3; j++)
		{
			out2<<B[i][j];
		}	
		out2<<endl;
	}
	out2<<endl;
}


void print_num1(ll n)
{
	ll f=0;
	if(n<0) out1<<"-";
	else out1<<" ";
	n=abs(n);
	if(n/10000>0) 		      {out1<<n/10000;     f=1;} else out1<<" ";
	if((n/1000)%10>0 or f==1) {out1<<(n/1000)%10; f=1;} else out1<<" ";
	if((n/100)%10>0  or f==1) {out1<<(n/100)%10;  f=1;} else out1<<" ";
	if((n/10)%10>0   or f==1) {out1<<(n/10)%10;   f=1;} else out1<<" ";
	out1<<n%10;
}
void print1()
{
	log<<"Sucsess"<<endl<<endl;
	for(ll i=0; i<3; i++)
	{
		for(ll j=0; j<3; j++) {
			print_num1(A[i][j]);
			out1<<" ";
		}
		out1<<endl;
	}
	for(ll i=0; i<3; i++)
	{
		for(ll j=0; j<3; j++)
		{
			out1<<B[i][j];
		}	
		out1<<endl;
	}
	out1<<endl;
}




ll mod_pattern()
{
	ll s=B[0][0]+B[0][1]+B[0][2]+B[1][0]+B[1][1]+B[1][2]+B[2][0]+B[2][1]+B[2][2];
	if(s==1)
	{
		ll x=0, y=0;
		ll X=0, Y=0;
		for(ll i=0; i<3; i++)
		for(ll j=0; j<3; j++)
		{
			if(B[i][j]) 
			{
				x=i;
				X=i;
				y=j;
				Y=i;
				break;
			}
		}
		while(x>0)
		{
			for(ll j=0; j<3; j++)
			{
				swap(C[x][j],C[x-1][j]);
				swap(D[x][j],D[x-1][j]);
			}
			x=x-1;
		}
		while(y>0)
		{
			for(ll i=0; i<3; i++)
			{
				swap(C[i][y],C[i][y-1]);
				swap(D[i][y],D[i][y-1]);
			}
			y=y-1;
		}
		return X+Y;
	}
}

ll reschebnik(ll a, ll b, ll S)
// 1 - можно решить матрицу
// 2 - нельзя решить матрицу
// 3 - данный случай вне поля зрения
{
	ll s=B[0][0]+B[0][1]+B[0][2]+B[1][0]+B[1][1]+B[1][2]+B[2][0]+B[2][1]+B[2][2];
	
	if(a>b)
	{
		cout<<"ERROR: a > b"<<endl;
		return 3;
	}
	log<<"BEGIN"<<endl<<a<<" "<<b<<endl;
	if(S==0) log<<"True, popali totschno"<<endl;
	if(S==1) log<<"True, popali"<<endl;
	if(S==2) log<<"True, popali blisko"<<endl;
	if(S==3) log<<"False, ne popali totschno"<<endl;
	if(S==4) log<<"False, ne popali"<<endl;
	if(S==5) log<<"False, ne popali w malij diapason"<<endl;
	if(mod_pattern()%2==1)
	{
		ll tmp=a;
		a=-b;
		b=-tmp;
	}
	
	if(s==1)
	{
		ll X22    =abs(C[1][1]*C[2][2]-C[1][2]*C[2][1]);
		ll X21_X12= C[0][1]*(C[1][0]*C[2][2]-C[2][0]*C[1][2]) - C[0][2]*(C[1][0]*C[2][1]-C[1][1]*C[2][0]);
		log<<"X22    : "<<X22<<endl;
		log<<"X21*X12: "<<X21_X12<<endl;
		log<<"Original det: "<<get_det()<<endl;
		if(X22==0)
		{
			if(get_det_C()>=a && get_det_C()<=b) return 1;
			else return 2;
		}
		log<<((a+X21_X12+X22-1)/X22)<<" <= "<<((b+X21_X12)/X22)<<" ?"<<endl;
		log<<(((a+X21_X12+X22-1)/X22)<=((b+X21_X12)/X22))<<endl;
		if(((a+X21_X12+X22-1)/X22)<=((b+X21_X12)/X22)) return 1;
		else return 2;
	}
	log<<"NO SOLVE"<<endl;
	return 3;
	
}

void sadatschnik()
{
	make_new_det();
	make_new_pattern();
	ll d=get_det();
	ll s = rand()%6;
	ll ans;
	if(s==0) // Подобрать значение точно
	{
		ans=reschebnik(d,d,s);
		if(ans==1) 	{out1<<d<<" "<<d<<":"<<endl; print1();}
		if(ans==2)	{out2<<d<<" "<<d<<":"<<endl; print2();}
		if(ans==3)  {out3<<d<<" "<<d<<":"<<endl; print3();}
	} 
	if(s==1) // Решение возможно в диапазоне:
	{
		ll l=d-rand();
		ll r=d+rand();
		ans=reschebnik(l,r,s);
		if(ans==1) 	{out1<<l<<" "<<r<<":"<<endl; print1();}
		if(ans==2)	{out2<<l<<" "<<r<<":"<<endl; print2();}
		if(ans==3)  {out3<<l<<" "<<r<<":"<<endl; print3();}
	}
	if(s==2) // Решение возможно в узком диапазоне:
	{
		ll l=d-rand()/1000;
		ll r=d+rand()/1000;
		ans=reschebnik(l,r,s);
		if(ans==1) 	{out1<<l<<" "<<r<<":"<<endl; print1();}
		if(ans==2)	{out2<<l<<" "<<r<<":"<<endl; print2();}
		if(ans==3)  {out3<<l<<" "<<r<<":"<<endl; print3();}
	}
	if(s==3) // Невозможно точное попадание:
	{
		ll l=d-rand()+16384;
		while(l==d) l=d-rand()+16384;
		ll r=l;
		ans=reschebnik(l,r,s);
		if(ans==2) 	{out1<<l<<" "<<r<<":"<<endl; print1();}
		if(ans==1)	{out2<<l<<" "<<r<<":"<<endl; print2();}
		if(ans==3)  {out3<<l<<" "<<r<<":"<<endl; print3();}
	}
	if(s==4) // Невозможно попадание в диапазон:
	{
		ll l=d+1+rand();
		ll r=l+rand();
		ans=reschebnik(l,r,s);
		if(ans==2) 	{out1<<l<<" "<<r<<":"<<endl; print1();}
		if(ans==1)	{out2<<l<<" "<<r<<":"<<endl; print2();}
		if(ans==3)  {out3<<l<<" "<<r<<":"<<endl; print3();}
	}
	if(s==5) // Невозможно попадание в малый диапазон:
	{
		ll l=d+1+rand()/1000;
		ll r=l+rand()/1000;
		ans=reschebnik(l,r,s);
		if(ans==2) 	{out1<<l<<" "<<r<<":"<<endl; print1();}
		if(ans==1)	{out2<<l<<" "<<r<<":"<<endl; print2();}
		if(ans==3)  {out3<<l<<" "<<r<<":"<<endl; print3();}
	}
}

signed main()
{
	srand(time(0));
	for(ll i=0; i<1000; i++)
	{
		if(i%10==0) cout<<i<<endl;
		sadatschnik();
	}
}