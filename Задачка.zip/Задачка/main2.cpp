#include<iostream>
#include<fstream>
#include<cstdlib>
#include<ctime>
using namespace std;

int A[3][3];
int B[3][3];
int N=2;
int count=2000;
int sucsess=0;
int d=0, l=0, r=0, s;
int x1=0, x2=0, x3=0;
int y1=0, y2=0, y3=0;
ofstream out("JMATRIX_level_2.txt");

void make_new_det()
{
	for(int i=0; i<3; i++)
	for(int j=0; j<3; j++)
	{
		A[i][j]=rand()%10;
	}
}
void make_new_pattern()
{
	if(N==2)
	{	
		
		x1=rand()%3;
		x2=rand()%3;
		y1=rand()%3;
		y2=rand()%3;
		if(x1==x2 && y1==y2) 
		{
			make_new_pattern();
			return;
		}
		A[x1][y1]=10;
		A[x2][y2]=10;
	}
	if(N==3)
	{	
		
		x1=rand()%3;
		x2=rand()%3;
		x3=rand()%3;
		y1=rand()%3;
		y2=rand()%3;
		y3=rand()%3;
		
		bool a12=bool(x1==x2 && y1==y2);
		bool a13=bool(x1==x3 && y1==y3);
		bool a23=bool(x2==x3 && y2==y3);
		if(a12 or a13 or a23)
		{
			make_new_pattern();
			return;
		}
		A[x1][y1]=10;
		A[x2][y2]=10;
		A[x3][y3]=10;
	}
}
int get_det()
{
	return A[0][0]*(A[1][1]*A[2][2]-A[1][2]*A[2][1])-A[0][1]*(A[1][0]*A[2][2]-A[1][2]*A[2][0])+A[0][2]*(A[1][0]*A[2][1]-A[1][1]*A[2][0]);
}

void print()
{
	for(int i=0; i<3; i++)
	{
		for(int j=0; j<3; j++)
		{
			if(A[i][j]<10)cout<<A[i][j]<<" ";
			else cout<<"X ";
		}
		cout<<endl;
	}
	cout<<endl;
}
void fprint()
{
	char a=34+16*A[0][0]+A[0][1]; out<<a;
	a=34+16*A[0][2]+A[1][0]; out<<a;
	a=34+16*A[1][1]+A[1][2]; out<<a;
	a=34+16*A[2][0]+A[2][1]; out<<a;
	a=34+16*A[2][2]+s; out<<a;
	if(l>0) out<<char(34+l)<<char(34);
	else out<<char(34)<<char(34-l);
	if(r>0) out<<char(34+r)<<char(34);
	else out<<char(34)<<char(34-r);
}
int main()
{
	// В среднем значение определителя - 120. Разброс по идее не большой.

	for(int i=0; i<count; i++)
	{
		make_new_det();
		print();
		d=get_det();
		if(abs(d)>150) 
		{
			i=i-1;
			continue;
		}
		make_new_pattern();
		s=rand()%6;
		if(s==0) // Подобрать значение точно
		{
			l=d;
			r=d;
		} 
		if(s==1) // Решение возможно в диапазоне:
		{
			l=d-rand()/1000;
			r=d+rand()/1000;
		}
		if(s==2) // Решение возможно в узком диапазоне:
		{
			l=d-rand()/10000;
			r=d+rand()/10000;
		}
		if(s==3) // Невозможно точное попадание:
		{
			l=d-rand()/1000+500;
			while(l==d) l=d-rand()/100+50;
			r=l;
		}
		if(s==4) // Невозможно попадание в диапазон:
		{
			l=d+1+rand()/1000;
			r=l+rand()/1000;
		}
		if(s==5) // Невозможно попадание в малый диапазон:
		{
			l=d+1+rand()/10000;
			r=l+rand()/10000;
		}
		if(abs(l)>150 or abs(r)>150) 
		{
			i=i-1;
			continue;
		}
		s=0;
		if(N==2)
		{
			for(int i1=0; i1<10; i1++)
			for(int i2=0; i2<10; i2++)
			{
				A[x1][y1]=i1;
				A[x2][y2]=i2;
				if(get_det()<=r and get_det()>=l) s=1;
			}
			A[x1][y1]=10;
			A[x2][y2]=10;
		}
		if(N==3)
		{
			for(int i1=0; i1<10; i1++)
			for(int i2=0; i2<10; i2++)
			for(int i3=0; i3<10; i3++)
			{
				A[x1][y1]=i1;
				A[x2][y2]=i2;
				A[x3][y3]=i3;
				if(get_det()<=r and get_det()>=l) s=1;
			}
			A[x1][y1]=10;
			A[x2][y2]=10;
			A[x3][y3]=10;
		}
		if(s==1 && sucsess>count/2)
		{
			i=i-1;
			continue;
		}
		sucsess=sucsess+s;
		print();
		cout<<l<<" "<<r<<" | "<<s<<endl;
		cout<<endl;
		fprint();
		cout<<endl;
	}

}